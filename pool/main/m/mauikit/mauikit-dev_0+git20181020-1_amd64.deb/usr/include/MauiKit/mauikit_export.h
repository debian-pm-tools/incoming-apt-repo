
#ifndef MAUIKIT_EXPORT_H
#define MAUIKIT_EXPORT_H

#ifdef MAUIKIT_STATIC_DEFINE
#  define MAUIKIT_EXPORT
#  define MAUIKIT_NO_EXPORT
#else
#  ifndef MAUIKIT_EXPORT
#    ifdef MauiKit_EXPORTS
        /* We are building this library */
#      define MAUIKIT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MAUIKIT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MAUIKIT_NO_EXPORT
#    define MAUIKIT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MAUIKIT_DEPRECATED
#  define MAUIKIT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MAUIKIT_DEPRECATED_EXPORT
#  define MAUIKIT_DEPRECATED_EXPORT MAUIKIT_EXPORT MAUIKIT_DEPRECATED
#endif

#ifndef MAUIKIT_DEPRECATED_NO_EXPORT
#  define MAUIKIT_DEPRECATED_NO_EXPORT MAUIKIT_NO_EXPORT MAUIKIT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MAUIKIT_NO_DEPRECATED
#    define MAUIKIT_NO_DEPRECATED
#  endif
#endif

#endif /* MAUIKIT_EXPORT_H */
